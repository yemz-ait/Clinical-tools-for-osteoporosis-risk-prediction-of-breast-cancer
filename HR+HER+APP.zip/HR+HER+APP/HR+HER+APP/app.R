# app.R
if (!require(pacman)) install.packages("pacman")
pacman::p_load(tidyverse, rms, Hmisc, shiny, shinythemes, plotly, stringi, shinyWidgets, rmarkdown, knitr, kableExtra)

# 检查并生成静态列线图
if (!file.exists("Static_Nomogram.png")) {
  data <- read.csv("HR+HER+.csv", fileEncoding = "UTF-8-BOM") %>%
    rename(gamma_GTP = `γ.GTP`) %>%
    mutate(Group = as.factor(Group),
           Group = relevel(Group, ref = "Control"))
  
  ddist <- datadist(data)
  options(datadist = "ddist")
  
  full_model <- lrm(Group ~ Age + Albumin + BMI + Creatinine + Direct.bilirubin + 
                      Hemoglobin + INR + K + LDH + lymphocyte + M + N + PHOS +
                      Platelet + PT + Red.blood.cell + urea.nitrogen + 
                      Uric.acid + White.blood.cells + gamma_GTP,
                    data = data, x = TRUE, y = TRUE)
  
  cindex <- round(full_model$stats["C"], 3)
  
  nom_plot <- nomogram(full_model,
                       lp = FALSE,
                       fun = plogis,
                       funlabel = "Risk of DN",
                       fun.at = c(0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99),
                       varname.label = TRUE,
                       abbrev = FALSE)
  
  png("Static_Nomogram.png", width = 2000, height = 1500, res = 150)
  plot(nom_plot,
       xfrac = 0.15,
       col.axis = "#2F4F4F",
       col.grid = c("#F0F8FF", "#FFE4E1"),
       lwd.grid = 1,
       cex.axis = 0.9,
       cex.var = 1.1,
       lmgp = 0.3,
       lwd = 1.5,
       cex.main = 1.5,
       main = "Clinical Diagnostic Nomogram for Osteoporosis Risk Prediction",
       label.every = 2)
  
  mtext("Predicting Osteoporosis Risk | HR+HER- Cohort", 
        side = 3, line = 0.3, cex = 1.2, col = "#8B0000")
  mtext(paste("All biomarkers included | Model C-index =", cindex), 
        side = 3, line -0.8, cex = 1.0, col = "#556B2F")
  legend("topright", 
         legend = c("Lower Risk", "Higher Risk"),
         fill = c("#F0F8FF", "#FFE4E1"),
         title = "Risk Gradient",
         cex = 1.0)
  dev.off()
}

# 创建报告模板（如果不存在）
if (!file.exists("report.Rmd")) {
  writeLines(
    c(
      "---",
      "title: 'Osteoporosis Risk Assessment Report'",
      "author: 'Clinical Decision Support System'",
      "date: '`r Sys.Date()`'",
      "output: pdf_document",
      "params:",
      "  patient_data: NA",
      "  risk_prediction: NA",
      "  model_summary: NA",
      "  cindex: NA",
      "---",
      "",
      "```{r setup, include=FALSE}",
      "knitr::opts_chunk$set(echo = FALSE, warning = FALSE, message = FALSE)",
      "library(knitr)",
      "library(kableExtra)",
      "```",
      "",
      "# Clinical Report: Osteoporosis Risk Assessment",
      "",
      "## Patient Parameters",
      "",
      "```{r patient-data}",
      "kable(params$patient_data, caption = 'Patient Clinical Parameters') %>%",
      "  kable_styling(bootstrap_options = c('striped', 'hover'), full_width = FALSE)",
      "```",
      "",
      "## Risk Prediction Results",
      "",
      "- **Total Risk Score:** `r round(params$risk_prediction$linear_predictor, 2)`",
      "- **Osteoporosis Risk Probability:** `r round(params$risk_prediction$probability * 100, 1)`%",
      "",
      "## Model Information",
      "",
      "- **Model C-index:** `r params$cindex`",
      "",
      "### Model Summary",
      "",
      "```{r model-summary}",
      "cat(params$model_summary, sep = '\n')",
      "```"
    ),
    "report.Rmd"
  )
}

# 主应用
data <- read.csv("HR+HER-.csv", fileEncoding = "UTF-8-BOM") %>%
  rename(gamma_GTP = `γ.GTP`) %>%
  mutate(Group = as.factor(Group),
         Group = relevel(Group, ref = "Control"))

ddist <- datadist(data)
options(datadist = "ddist")

full_model <- lrm(Group ~ Age + Albumin + BMI + Creatinine + Direct.bilirubin + 
                    Hemoglobin + INR + K + LDH + lymphocyte + M + N + PHOS +
                    Platelet + PT + Red.blood.cell + urea.nitrogen + 
                    Uric.acid + White.blood.cells + gamma_GTP,
                  data = data, x = TRUE, y = TRUE)

cindex <- round(full_model$stats["C"], 3)

# UI
ui <- fluidPage(
  theme = shinytheme("flatly"),
  titlePanel("Interactive Clinical Nomogram for Osteoporosis Risk Prediction"),
  
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Patient Parameters"),
      
      # 动态创建输入控件
      lapply(names(data)[-ncol(data)], function(var) {
        if (is.numeric(data[[var]])) {
          sliderInput(
            inputId = var,
            label = var,
            min = floor(min(data[[var]], na.rm = TRUE)),
            max = ceiling(max(data[[var]], na.rm = TRUE)),
            value = median(data[[var]], na.rm = TRUE),
            step = 0.1
          )
        } else {
          selectInput(
            inputId = var,
            label = var,
            choices = unique(data[[var]]),
            selected = unique(data[[var]])[1]
          )
        }
      }),
      
      actionButton("reset", "Reset to Median Values", class = "btn-warning"),
      hr(),
      downloadButton("report", "Generate PDF Report", class = "btn-success")
    ),
    
    mainPanel(
      width = 8,
      tabsetPanel(
        tabPanel("Nomogram", 
                 imageOutput("nomogramPlot", height = "800px"),
                 h3(textOutput("riskScore"), align = "center"),
                 h4(textOutput("riskProbability"), align = "center")
        ),
        tabPanel("Model Summary", 
                 verbatimTextOutput("modelSummary")
        ),
        tabPanel("Patient Data",
                 dataTableOutput("patientTable")
        )
      )
    )
  )
)

# Server
server <- function(input, output, session) {
  output$nomogramPlot <- renderImage({
    list(src = "Static_Nomogram.png",
         contentType = "image/png",
         width = "100%",
         height = "auto")
  }, deleteFile = FALSE)
  
  observeEvent(input$reset, {
    lapply(names(data)[-ncol(data)], function(var) {
      if (is.numeric(data[[var]])) {
        updateSliderInput(session, var, value = median(data[[var]], na.rm = TRUE))
      } else {
        updateSelectInput(session, var, selected = unique(data[[var]])[1])
      }
    })
  })
  
  patientData <- reactive({
    df <- data.frame(
      Age = input$Age,
      Albumin = input$Albumin,
      BMI = input$BMI,
      Creatinine = input$Creatinine,
      Direct.bilirubin = input$Direct.bilirubin,
      Hemoglobin = input$Hemoglobin,
      INR = input$INR,
      K = input$K,
      LDH = input$LDH,
      lymphocyte = input$lymphocyte,
      M = input$M,
      N = input$N,
      PHOS = input$PHOS,
      Platelet = input$Platelet,
      PT = input$PT,
      Red.blood.cell = input$Red.blood.cell,
      urea.nitrogen = input$urea.nitrogen,
      Uric.acid = input$Uric.acid,
      White.blood.cells = input$White.blood.cells,
      gamma_GTP = input$gamma_GTP
    )
    return(df)
  })
  
  riskPrediction <- reactive({
    new_data <- patientData()
    lp <- predict(full_model, newdata = new_data, type = "lp")
    prob <- predict(full_model, newdata = new_data, type = "fitted")
    list(linear_predictor = lp, probability = prob)
  })
  
  output$riskScore <- renderText({
    pred <- riskPrediction()
    paste("Total Risk Score:", round(pred$linear_predictor, 2))
  })
  
  output$riskProbability <- renderText({
    pred <- riskPrediction()
    paste("Osteoporosis Risk Probability:", round(pred$probability * 100, 1), "%")
  })
  
  output$modelSummary <- renderPrint({
    full_model
  })
  
  output$patientTable <- renderDataTable({
    patientData()
  }, options = list(pageLength = 5))
  
  output$report <- downloadHandler(
    filename = function() {
      paste("Osteoporosis-Risk-Report-", Sys.Date(), ".pdf", sep = "")
    },
    content = function(file) {
      tempReport <- file.path(tempdir(), "report.Rmd")
      file.copy("report.Rmd", tempReport, overwrite = TRUE)
      
      params <- list(
        patient_data = patientData(),
        risk_prediction = riskPrediction(),
        model_summary = capture.output(print(full_model)),
        cindex = cindex
      )
      
      rmarkdown::render(tempReport, 
                        output_file = file,
                        params = params,
                        envir = new.env(parent = globalenv()))
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)